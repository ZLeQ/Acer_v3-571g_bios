[SOP]
1. DOS flash: Please kindly see <DOS folder> and system reboot to boot to pure Dos mode. Then, execute "Update.BAT"batch file to update bios under pure Dos mode.
2. Windows flash: Please see <Windows> under windows mode and click "Q5WV1109.exe" to update bios.