[SOP]
1. DOS flash: Please execute "BIOS.BAT" batch file to update bios under pure Dos mode.
2. Windows flash: Please click "Q5WV1105.exe" to update bios.